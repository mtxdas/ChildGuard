"use client";

import { useState, useEffect, useRef, useCallback } from "react";
import { motion, AnimatePresence, useMotionValue, animate } from "framer-motion";
import { Mic, MicOff, Settings, Send, X, Loader2, Zap } from "lucide-react";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";
import { handleCommand } from "@/lib/commands";
import { askGemini, ChatTurn } from "@/lib/gemini";
import { geminiTtsAudio } from "@/lib/tts";
import { ApiKeyPanel } from "@/components/api-key-panel";

// ---- Web Speech API minimal typings ----
interface SpeechRecognitionEventLike {
  resultIndex: number;
  results: { length: number; [i: number]: { isFinal: boolean; [j: number]: { transcript: string } } };
}
interface SpeechRecognitionLike {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  start: () => void;
  stop: () => void;
  abort: () => void;
  onresult: ((e: SpeechRecognitionEventLike) => void) | null;
  onend: (() => void) | null;
  onerror: ((e: { error: string }) => void) | null;
}

interface Message {
  role: "user" | "bot";
  text: string;
}

// "ও ক্ষ্যাপা" — wake word (উচ্চারণের রকমফের সহ)
const WAKE_REGEX = /(?:ও+|o+h?|oi)\s*[,.]?\s*(?:ক্ষ্যাপা|খ্যাপা|খেপা|ক্ষেপা|ক্ষ্যাপ|khepa|khyapa|khapa|kheppa)/gi;
const AWAKE_MS = 45000;
const SILENCE_MS = 1800;

function stripForSpeech(text: string): string {
  return text
    .replace(/[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}\u{FE0F}]/gu, "")
    .replace(/\*+/g, "")
    .trim();
}

export function Khyapa() {
  const [open, setOpen] = useState(false);
  const [micOn, setMicOn] = useState(false);
  const [awake, setAwake] = useState(false);
  const [status, setStatus] = useState<"idle" | "listening" | "thinking" | "speaking">("idle");
  const [messages, setMessages] = useState<Message[]>([]);
  const [interim, setInterim] = useState("");
  const [textInput, setTextInput] = useState("");
  const [apiKey, setApiKey] = useState("");
  const [showSetup, setShowSetup] = useState(false);
  const [supported, setSupported] = useState(true);

  const recRef = useRef<SpeechRecognitionLike | null>(null);
  const micOnRef = useRef(false);
  const awakeRef = useRef(false);
  const speakingRef = useRef(false);
  const processingRef = useRef(false);
  const apiKeyRef = useRef("");
  const historyRef = useRef<ChatTurn[]>([]);
  const awakeTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const scrollRef = useRef<HTMLDivElement | null>(null);
  const voiceRef = useRef<SpeechSynthesisVoice | null>(null);
  const bufferRef = useRef("");
  const silenceTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const micBusyRef = useRef(false);
  const dragMovedRef = useRef(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const bubbleRef = useRef<HTMLButtonElement | null>(null);

  // মেসেঞ্জার-স্টাইল বাবলের অবস্থান
  const bubbleX = useMotionValue(0);
  const bubbleY = useMotionValue(0);

  // ---- load api key ----
  useEffect(() => {
    const saved = localStorage.getItem("khyapa_api_key") || "";
    setApiKey(saved);
    apiKeyRef.current = saved;
    if (!saved) setShowSetup(true);
  }, []);

  // ---- fallback ব্রাউজার মেয়ে কণ্ঠ ----
  useEffect(() => {
    const pick = () => {
      const voices = window.speechSynthesis?.getVoices() || [];
      const bn = voices.filter((v) => v.lang.toLowerCase().startsWith("bn"));
      const female = bn.find((v) => /female|মহিলা|woman/i.test(v.name));
      const notMale = bn.find((v) => !/male|পুরুষ/i.test(v.name));
      voiceRef.current = female || notMale || bn[0] || voices.find((v) => v.lang.toLowerCase().startsWith("hi")) || null;
    };
    pick();
    window.speechSynthesis?.addEventListener("voiceschanged", pick);
    return () => window.speechSynthesis?.removeEventListener("voiceschanged", pick);
  }, []);

  // ---- auto scroll ----
  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, interim]);

  const setAwakeState = useCallback((v: boolean) => {
    awakeRef.current = v;
    setAwake(v);
    if (awakeTimerRef.current) clearTimeout(awakeTimerRef.current);
    if (v) {
      awakeTimerRef.current = setTimeout(() => {
        awakeRef.current = false;
        setAwake(false);
      }, AWAKE_MS);
    }
  }, []);

  const finishSpeaking = useCallback(() => {
    speakingRef.current = false;
    setStatus(micOnRef.current ? "listening" : "idle");
    if (micOnRef.current) {
      try {
        recRef.current?.start();
      } catch {}
    }
  }, []);

  const speak = useCallback(
    async (text: string) => {
      const clean = stripForSpeech(text);
      if (!clean || typeof window === "undefined") return;
      speakingRef.current = true;
      setStatus("speaking");
      try {
        recRef.current?.abort();
      } catch {}
      window.speechSynthesis?.cancel();

      // ১) Gemini-র মিষ্টি মেয়ে কণ্ঠ (ফ্রি API দিয়ে)
      if (apiKeyRef.current) {
        const url = await geminiTtsAudio(apiKeyRef.current, clean);
        if (url) {
          const audio = new Audio(url);
          audioRef.current = audio;
          audio.onended = () => {
            URL.revokeObjectURL(url);
            finishSpeaking();
          };
          audio.onerror = audio.onended as () => void;
          try {
            await audio.play();
            return;
          } catch {
            URL.revokeObjectURL(url);
          }
        }
      }

      // ২) fallback: ব্রাউজারের মেয়ে কণ্ঠ
      if (!window.speechSynthesis) {
        finishSpeaking();
        return;
      }
      const u = new SpeechSynthesisUtterance(clean);
      u.lang = "bn-BD";
      if (voiceRef.current) u.voice = voiceRef.current;
      u.rate = 0.98;
      u.pitch = 1.2; // নরম মেয়ে কণ্ঠের টোন
      u.onend = finishSpeaking;
      u.onerror = finishSpeaking;
      window.speechSynthesis.speak(u);
    },
    [finishSpeaking]
  );

  const addBot = useCallback(
    (text: string, say = true) => {
      setMessages((m) => [...m, { role: "bot", text }]);
      historyRef.current.push({ role: "model", text });
      if (say) speak(text);
    },
    [speak]
  );

  const processInput = useCallback(
    async (raw: string) => {
      const text = raw.trim();
      if (!text || processingRef.current) return;
      processingRef.current = true;
      setMessages((m) => [...m, { role: "user", text }]);
      historyRef.current.push({ role: "user", text });
      setAwakeState(true);

      const cmd = handleCommand(text);
      if (cmd.handled && cmd.reply) {
        addBot(cmd.reply);
        if (cmd.url) setTimeout(() => window.open(cmd.url, "_blank"), 1200);
        processingRef.current = false;
        return;
      }

      if (!apiKeyRef.current) {
        addBot("বন্ধু, আমার ব্রেইনটা এখনো চালু হয়নি! ⚙️ সেটিংসে গিয়ে ফ্রি API key বসিয়ে দাও, তারপর জমবে আড্ডা! 😜");
        setShowSetup(true);
        processingRef.current = false;
        return;
      }

      setStatus("thinking");
      try {
        const reply = await askGemini(apiKeyRef.current, historyRef.current.slice(0, -1), text);
        addBot(reply);
      } catch (e) {
        const msg = e instanceof Error ? e.message : "";
        if (msg === "INVALID_KEY") {
          addBot("উফ! API key-টা মনে হয় ভুল আছে বন্ধু 😅 সেটিংসে গিয়ে আবার চেক করো।");
          setShowSetup(true);
        } else if (msg === "RATE_LIMIT") {
          addBot("উফ, ফ্রি লিমিটে চাপ পড়েছে বন্ধু! 😮‍💨 এক মিনিট পরে আবার বলো — অথবা নতুন একটা ফ্রি key বানিয়ে বসাও।");
        } else {
          addBot("ইশ, নেটে একটু গোলমাল হলো মনে হয় 🙈 আরেকবার বলো তো!");
        }
      }
      processingRef.current = false;
    },
    [addBot, setAwakeState]
  );

  const handleUtterance = useCallback(
    (utterance: string) => {
      const hasWake = WAKE_REGEX.test(utterance);
      WAKE_REGEX.lastIndex = 0;

      if (!awakeRef.current) {
        if (!hasWake) return;
        const rest = utterance.replace(WAKE_REGEX, " ").replace(/\s+/g, " ").trim();
        WAKE_REGEX.lastIndex = 0;
        setAwakeState(true);
        setOpen(true);
        if (rest.length > 2) {
          processInput(rest);
        } else {
          const greetings = ["বলো বন্ধু, শুনছি! 😊", "হাজির! কী করতে হবে বলো 🫡", "ডাকলে আর ক্ষ্যাপা আসবে না, তা কি হয়? বলো! 😜"];
          const g = greetings[Math.floor(Math.random() * greetings.length)];
          setMessages((m) => [...m, { role: "bot", text: g }]);
          speak(g);
        }
        return;
      }

      const cleaned = utterance.replace(WAKE_REGEX, " ").replace(/\s+/g, " ").trim();
      WAKE_REGEX.lastIndex = 0;
      if (cleaned.length > 1) processInput(cleaned);
    },
    [processInput, setAwakeState, speak]
  );

  const handleUtteranceRef = useRef(handleUtterance);
  useEffect(() => {
    handleUtteranceRef.current = handleUtterance;
  }, [handleUtterance]);

  // ---- speech recognition ----
  useEffect(() => {
    const w = window as unknown as { SpeechRecognition?: new () => SpeechRecognitionLike; webkitSpeechRecognition?: new () => SpeechRecognitionLike };
    const SR = w.SpeechRecognition || w.webkitSpeechRecognition;
    if (!SR) {
      setSupported(false);
      return;
    }
    const rec = new SR();
    rec.lang = "bn-BD";
    rec.continuous = true;
    rec.interimResults = true;

    const scheduleProcess = () => {
      if (silenceTimerRef.current) clearTimeout(silenceTimerRef.current);
      silenceTimerRef.current = setTimeout(() => {
        const utterance = bufferRef.current.replace(/\s+/g, " ").trim();
        bufferRef.current = "";
        setInterim("");
        // সেশন রিসেট — পুরোনো কথা যেন আবার না আসে (ডাবল লেখা বন্ধ)
        try {
          rec.abort();
        } catch {}
        if (utterance) handleUtteranceRef.current(utterance);
      }, SILENCE_MS);
    };

    rec.onresult = (e) => {
      if (speakingRef.current) return;
      // পুরো সেশনের transcript নতুন করে বানাও — জমা করা না (Android-এ ডাবল আসা ঠেকায়)
      let full = "";
      for (let i = 0; i < e.results.length; i++) {
        full += e.results[i][0].transcript + " ";
      }
      bufferRef.current = full;
      setInterim(full.replace(/\s+/g, " ").trim());
      scheduleProcess();
    };

    rec.onend = () => {
      if (micOnRef.current && !speakingRef.current) {
        setTimeout(() => {
          try {
            rec.start();
          } catch {}
        }, 250);
      }
    };
    rec.onerror = (e) => {
      if (e.error === "not-allowed") {
        micOnRef.current = false;
        setMicOn(false);
        setStatus("idle");
        setMessages((m) => [...m, { role: "bot", text: "মাইকের অনুমতি দাওনি বন্ধু! 🎤 ব্রাউজারে মাইক allow করে আবার চেষ্টা করো।" }]);
      }
    };

    recRef.current = rec;
    return () => {
      micOnRef.current = false;
      if (silenceTimerRef.current) clearTimeout(silenceTimerRef.current);
      try {
        rec.abort();
      } catch {}
    };
  }, []);

  const toggleMic = useCallback(async () => {
    if (!recRef.current || micBusyRef.current) return;
    micBusyRef.current = true;
    try {
      if (micOnRef.current) {
        micOnRef.current = false;
        setMicOn(false);
        setStatus("idle");
        try {
          recRef.current.abort();
        } catch {}
      } else {
        try {
          const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
          stream.getTracks().forEach((t) => t.stop());
        } catch {
          setMessages((m) => [
            ...m,
            {
              role: "bot",
              text: "মাইক খুলতে পারছি না বন্ধু! 🎤🚫 প্রিভিউ উইন্ডোতে মাইক ব্লক থাকে — উপরের ↗️ (open in new tab) আইকনে চেপে আমাকে আলাদা ট্যাবে খোলো, তারপর মাইক Allow করো।",
            },
          ]);
          return;
        }
        micOnRef.current = true;
        setMicOn(true);
        setStatus("listening");
        try {
          recRef.current.start();
        } catch {}
      }
    } finally {
      micBusyRef.current = false;
    }
  }, []);

  const sendText = useCallback(() => {
    if (!textInput.trim()) return;
    processInput(textInput);
    setTextInput("");
  }, [textInput, processInput]);

  const saveKey = useCallback((k: string) => {
    localStorage.setItem("khyapa_api_key", k);
    setApiKey(k);
    apiKeyRef.current = k;
    setShowSetup(false);
    setMessages((m) => [...m, { role: "bot", text: "ব্রেইন চালু! 🧠⚡ এবার আমি ফুল পাওয়ারে — যা খুশি জিজ্ঞেস করো বন্ধু! 😊" }]);
  }, []);

  // মেসেঞ্জারের মতো — ছাড়লে কাছের কিনারায় লেগে যাবে
  const snapToEdge = useCallback(() => {
    const el = bubbleRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const margin = 12;
    const goLeft = centerX < window.innerWidth / 2;
    const deltaX = goLeft ? margin - rect.left : window.innerWidth - margin - rect.right;
    animate(bubbleX, bubbleX.get() + deltaX, { type: "spring", stiffness: 400, damping: 30 });
    // উপরে-নিচে স্ক্রিনের বাইরে গেলে ফিরিয়ে আনো
    if (rect.top < margin) {
      animate(bubbleY, bubbleY.get() + (margin - rect.top), { type: "spring", stiffness: 400, damping: 30 });
    } else if (rect.bottom > window.innerHeight - margin) {
      animate(bubbleY, bubbleY.get() - (rect.bottom - (window.innerHeight - margin)), { type: "spring", stiffness: 400, damping: 30 });
    }
  }, [bubbleX, bubbleY]);

  const statusText =
    status === "speaking" ? "কথা বলছি..." : status === "thinking" ? "ভাবছি... 🤔" : micOn ? (awake ? "শুনছি... বলো!" : '"ও ক্ষ্যাপা" বলে ডাকো') : "মাইক বন্ধ";

  return (
    <>
      {showSetup && <ApiKeyPanel onSave={saveKey} onClose={() => setShowSetup(false)} currentKey={apiKey} />}

      {/* ---- মেসেঞ্জার-স্টাইল ফ্লোটিং বাবল ---- */}
      <AnimatePresence>
        {!open && (
          <motion.button
            ref={bubbleRef}
            drag
            dragMomentum={false}
            dragElastic={0.08}
            style={{ x: bubbleX, y: bubbleY }}
            onDragStart={() => {
              dragMovedRef.current = true;
            }}
            onDragEnd={() => {
              snapToEdge();
              setTimeout(() => {
                dragMovedRef.current = false;
              }, 120);
            }}
            onClick={() => {
              if (!dragMovedRef.current) setOpen(true);
            }}
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            exit={{ scale: 0 }}
            whileTap={{ scale: 0.92 }}
            className={cn(
              "fixed bottom-6 right-4 z-50 flex h-16 w-16 cursor-grab touch-none items-center justify-center rounded-full border-2 border-white/20 shadow-2xl active:cursor-grabbing",
              "bg-gradient-to-br from-violet-600 to-fuchsia-600 text-white",
              micOn && "ring-4 ring-violet-400/50"
            )}
          >
            {micOn && <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-violet-500 opacity-30" />}
            <span className="pointer-events-none text-3xl">😜</span>
          </motion.button>
        )}
      </AnimatePresence>

      {/* ---- চ্যাট প্যানেল ---- */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: 40, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 40, scale: 0.95 }}
            className="fixed bottom-4 right-4 z-50 flex h-[560px] w-[360px] max-w-[calc(100vw-2rem)] flex-col overflow-hidden rounded-2xl border border-violet-500/30 bg-zinc-900 shadow-2xl max-h-[calc(100vh-2rem)]"
          >
            <div className="flex items-center justify-between bg-gradient-to-r from-violet-700 to-fuchsia-700 px-4 py-3">
              <div className="flex items-center gap-2">
                <span className="text-2xl">😜</span>
                <div>
                  <p className="font-bold leading-tight text-white">ক্ষ্যাপা</p>
                  <p className="flex items-center gap-1 text-xs text-violet-200">
                    <span className={cn("inline-block h-2 w-2 rounded-full", status === "idle" ? "bg-zinc-400" : status === "thinking" ? "bg-amber-400" : "bg-green-400 animate-pulse")} />
                    {statusText}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-1">
                <button onClick={() => setShowSetup(true)} className="rounded-lg p-2 text-violet-200 hover:bg-white/10">
                  <Settings className="h-4 w-4" />
                </button>
                <button onClick={() => setOpen(false)} className="rounded-lg p-2 text-violet-200 hover:bg-white/10">
                  <X className="h-4 w-4" />
                </button>
              </div>
            </div>

            <div ref={scrollRef} className="flex-1 space-y-3 overflow-y-auto p-4">
              {messages.length === 0 && (
                <div className="mt-8 space-y-3 text-center text-sm text-zinc-400">
                  <p className="text-4xl">🎤</p>
                  <p>
                    মাইক চালু করে <span className="font-bold text-violet-400">&quot;ও ক্ষ্যাপা&quot;</span> বলে ডাকো!
                  </p>
                  <div className="mx-auto max-w-[260px] space-y-1 rounded-xl bg-zinc-800/60 p-3 text-left text-xs">
                    <p>💬 &quot;ও ক্ষ্যাপা, ইউটিউব খোলো&quot;</p>
                    <p>💬 &quot;ও ক্ষ্যাপা, কয়টা বাজে?&quot;</p>
                    <p>💬 &quot;ও ক্ষ্যাপা, ইউটিউবে গান চালাও&quot;</p>
                    <p>💬 &quot;ও ক্ষ্যাপা, একটা জোক বলো&quot;</p>
                  </div>
                </div>
              )}
              {messages.map((m, i) => (
                <div key={i} className={cn("flex", m.role === "user" ? "justify-end" : "justify-start")}>
                  <div
                    className={cn(
                      "max-w-[80%] rounded-2xl px-3 py-2 text-sm",
                      m.role === "user" ? "rounded-br-sm bg-violet-600 text-white" : "rounded-bl-sm bg-zinc-800 text-zinc-100"
                    )}
                  >
                    {m.text}
                  </div>
                </div>
              ))}
              {interim && (
                <div className="flex justify-end">
                  <div className="max-w-[80%] rounded-2xl rounded-br-sm bg-violet-600/40 px-3 py-2 text-sm italic text-violet-100">{interim}...</div>
                </div>
              )}
              {status === "thinking" && (
                <div className="flex justify-start">
                  <div className="flex items-center gap-2 rounded-2xl bg-zinc-800 px-3 py-2 text-sm text-zinc-400">
                    <Loader2 className="h-3 w-3 animate-spin" /> ভাবছি...
                  </div>
                </div>
              )}
            </div>

            {!supported && (
              <div className="border-t border-zinc-800 bg-amber-950/40 px-4 py-2 text-xs text-amber-300">
                ⚠️ এই ব্রাউজারে ভয়েস কাজ করবে না — Chrome ব্যবহার করো। টাইপ করে চ্যাট চলবে।
              </div>
            )}

            <div className="flex items-center gap-2 border-t border-zinc-800 p-3">
              <button
                onClick={toggleMic}
                disabled={!supported}
                className={cn(
                  "flex h-11 w-11 shrink-0 items-center justify-center rounded-full transition-colors",
                  micOn ? "bg-red-600 text-white hover:bg-red-500" : "bg-violet-600 text-white hover:bg-violet-500",
                  !supported && "opacity-40"
                )}
              >
                {micOn ? <MicOff className="h-5 w-5" /> : <Mic className="h-5 w-5" />}
              </button>
              <Input
                value={textInput}
                onChange={(e) => setTextInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && sendText()}
                placeholder="অথবা টাইপ করো..."
                className="border-zinc-700 bg-zinc-800 text-zinc-100 placeholder:text-zinc-500"
              />
              <button onClick={sendText} className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-zinc-800 text-violet-400 hover:bg-zinc-700">
                <Send className="h-5 w-5" />
              </button>
            </div>

            {awake && (
              <div className="flex items-center justify-center gap-1 bg-green-950/60 py-1 text-xs text-green-400">
                <Zap className="h-3 w-3" /> ক্ষ্যাপা জেগে আছে — সরাসরি বলো
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
