"use client";

import { Khyapa } from "@/components/khyapa";
import { Mic, Zap, MessageCircle, Globe } from "lucide-react";

const features = [
  { icon: Mic, title: "বাংলা ভয়েসে কথা", desc: "বাংলায় বলো, ক্ষ্যাপা বাংলায় ভয়েসে উত্তর দেবে" },
  { icon: Zap, title: "নাম ধরে ডাকো", desc: 'মাইক চালু রেখে "ক্ষ্যাপা" বললেই জেগে উঠবে' },
  { icon: Globe, title: "ভয়েস কমান্ডে কাজ", desc: "ইউটিউব খোলা, গুগল সার্চ, সময় বলা — মুখে বললেই হবে" },
  { icon: MessageCircle, title: "আড্ডাবাজ বন্ধু", desc: "কাজের সময় সিরিয়াস, আড্ডার সময় দুষ্টু 😜" },
];

export default function Home() {
  return (
    <main className="min-h-screen bg-gradient-to-b from-zinc-950 via-violet-950/30 to-zinc-950 text-zinc-100">
      <div className="mx-auto max-w-3xl px-6 py-16 text-center">
        <p className="mb-4 text-7xl">😜</p>
        <h1 className="mb-3 bg-gradient-to-r from-violet-400 to-fuchsia-400 bg-clip-text text-5xl font-extrabold text-transparent">
          ক্ষ্যাপা
        </h1>
        <p className="mb-2 text-lg text-zinc-300">তোমার নিজস্ব বাংলা ভয়েস AI বন্ধু</p>
        <p className="mb-10 text-sm text-zinc-500">স্মার্ট 🎯 • আড্ডাবাজ 😜 • সম্পূর্ণ ফ্রি 💸</p>

        <div className="mb-12 grid grid-cols-1 gap-4 sm:grid-cols-2">
          {features.map((f) => (
            <div key={f.title} className="rounded-2xl border border-violet-500/20 bg-zinc-900/60 p-5 text-left">
              <f.icon className="mb-3 h-6 w-6 text-violet-400" />
              <h3 className="mb-1 font-semibold">{f.title}</h3>
              <p className="text-sm text-zinc-400">{f.desc}</p>
            </div>
          ))}
        </div>

        <div className="rounded-2xl border border-violet-500/20 bg-zinc-900/60 p-6 text-left">
          <h2 className="mb-3 font-bold text-violet-300">🚀 ব্যবহারের নিয়ম</h2>
          <ol className="list-decimal space-y-2 pl-5 text-sm text-zinc-300">
            <li>ডান-নিচের 😜 ফ্লোটিং বাটনে ট্যাপ করো</li>
            <li>🎤 মাইক বাটন চেপে অনুমতি (allow) দাও</li>
            <li>
              <span className="font-semibold text-violet-300">&quot;ক্ষ্যাপা&quot;</span> বলে ডাকো — সে সাড়া দেবে!
            </li>
            <li>তারপর মুখে কমান্ড দাও বা আড্ডা জমাও 😄</li>
          </ol>
          <p className="mt-4 text-xs text-zinc-500">
            💡 সবচেয়ে ভালো চলে Chrome ব্রাউজারে (মোবাইল ও কম্পিউটার দুটোতেই)। ফোনে হোম স্ক্রিনে অ্যাড করে অ্যাপের মতো ব্যবহার করতে পারো।
          </p>
        </div>
      </div>

      <Khyapa />
    </main>
  );
}
